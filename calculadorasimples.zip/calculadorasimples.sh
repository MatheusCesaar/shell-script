#!/bin/bash

echo " Digite o primeiro número: "
read num1

echo " Digite o segundo numero: "
read num2

soma = $(( num1 + num2 ))
subtracao = $(( num1 - num2 ))
multiplicacao = $(( num1 * num2 ))
divisao = $(( num1 / num2 ))

echo "Resultados:"
echo "Soma:" $soma
echo "Subtração:" $subtracao
echo "Multiplicação:" $multiplicacao
echo "Divisão:" $divisao


