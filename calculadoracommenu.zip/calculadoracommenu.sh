#!/bin/bash

echo "Digite o primeiro número:"
read num 1 

echo "Digite o segundo numero:"
read num2

echo "Escolha a operação matemática:"
echo "1. Adição"
echo "2. Subtração"
echo "3. Multiplicação"
echo "4. Divisão"
read opcao

case $opcao in
1) resultado=$((num1 + num2))
echo "Resultado da adição: $resultado" ;;
2) resultado=$((num1 - num2))
echo "Resultado da subtração: $resultado" ;;
3) resultado=$((num1 * num2))
echo "Resultado da multiplicação: $resultado" ;;
4) resultado=$((num1 / num2))
echo "Resultado da divisão: $resultado" ;;
esac

